create table resume(
    id bigserial not null,
    about_me varchar(255),
    age integer,
    birth_day varchar(255),
    create_date timestamp(6),
    education varchar(255),
    email varchar(255),
    gender varchar(255),
    married boolean,
    languages varchar(255),
    location varchar(255),
    name varchar(255),
    patronymic varchar(255),
    phone varchar(255),
    position varchar(255),
    salary integer,
    skills varchar(255),
    status varchar(255),
    surname varchar(255),
    work_place varchar(255),
    user_id bigint,
    primary key (id)
);


create table role (
    id varchar(255) not null,
     primary key (id));

create table users (
    id bigserial not null,
    create_date timestamp(6),
    password varchar(255),
     username varchar(255),
     role_id varchar(255),
     primary key (id));


create table vacancy (
    id bigserial not null,
    about_company varchar(255),
    about_vacancy varchar(255),
    create_date timestamp(6),
    experience varchar(255),
    job_title varchar(255),
    location varchar(255),
    requirements varchar(255),
    salary integer,
    status varchar(255),
    work_type varchar(255),
    user_id bigint,
    primary key (id));


alter table if exists resume add constraint FKpv0whudowxosfu792veo6s2c0 foreign key (user_id) references users;
alter table if exists users add constraint FK4qu1gr772nnf6ve5af002rwya foreign key (role_id) references role;
alter table if exists vacancy add constraint FK8r2xu5td20shvcby0tct7upj4 foreign key (user_id) references users;