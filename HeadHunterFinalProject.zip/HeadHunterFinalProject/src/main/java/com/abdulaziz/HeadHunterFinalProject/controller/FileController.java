package com.abdulaziz.HeadHunterFinalProject.controller;

public class FileController {

    //getFIle
    //deleteFIle

}
