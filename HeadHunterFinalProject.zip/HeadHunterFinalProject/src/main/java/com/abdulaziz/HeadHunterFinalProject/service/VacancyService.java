package com.abdulaziz.HeadHunterFinalProject.service;

import com.abdulaziz.HeadHunterFinalProject.model.VacancyEntity;
import com.abdulaziz.HeadHunterFinalProject.repository.VacancyRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VacancyService {
    private final VacancyRepository vacancyRepository;

    @Autowired
    public VacancyService(VacancyRepository vacancyRepository) {
        this.vacancyRepository = vacancyRepository;
    }

    public List<VacancyEntity> findAll(){
        return vacancyRepository.findAll();
    }

    public Optional<VacancyEntity> getById(Long id){
        return Optional.ofNullable(vacancyRepository.findById(id).orElse(null));
    }

    @Transactional
    public void save(VacancyEntity vacancyEntity){
        vacancyRepository.save(vacancyEntity);
    }

    @Transactional
    public void update(long id, VacancyEntity vacancyEntity){
        vacancyEntity.setId(id);
        vacancyRepository.save(vacancyEntity);
    }

    @Transactional
    public void delete(long id){
        vacancyRepository.deleteById(id);
    }

}
