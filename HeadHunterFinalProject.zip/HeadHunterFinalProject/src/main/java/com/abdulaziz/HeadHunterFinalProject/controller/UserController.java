package com.abdulaziz.HeadHunterFinalProject.controller;


import com.abdulaziz.HeadHunterFinalProject.dto.UserDTO;
import com.abdulaziz.HeadHunterFinalProject.model.UserEntity;
import com.abdulaziz.HeadHunterFinalProject.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    private final ModelMapper mapper;

    @Autowired
    public UserController(UserService userService, ModelMapper mapper) {
        this.userService = userService;
        this.mapper = mapper;
    }

    @GetMapping
    public List<UserDTO> getUsers(){
        return userService.findAll().stream()
                .map(this::convertToUserDTO).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public Optional<UserDTO> getUserById(@PathVariable("id") long id){
        return Optional.ofNullable(convertToUserDTO(userService.getById(id).get()));
    }

    public UserEntity convertToUser(UserDTO userDTO){
        return mapper.map(userDTO, UserEntity.class);
    }
    public UserDTO convertToUserDTO(UserEntity userEntity){
        return mapper.map(userEntity, UserDTO.class);
    }


    @PostMapping
    public ResponseEntity<HttpStatus> create(@RequestBody UserDTO userDTO){
        userService.save(convertToUser(userDTO));
        return ResponseEntity.ok(HttpStatus.CREATED);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<HttpStatus> update(@RequestBody UserDTO userDTO, @PathVariable long id){
        userService.update(id,convertToUser(userDTO));
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> delete(@PathVariable(name = "id") long id){
        userService.delete(id);
        return ResponseEntity.ok(HttpStatus.OK);
    }




}
