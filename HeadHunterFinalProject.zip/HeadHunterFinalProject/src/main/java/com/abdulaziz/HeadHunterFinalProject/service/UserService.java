package com.abdulaziz.HeadHunterFinalProject.service;


import com.abdulaziz.HeadHunterFinalProject.model.UserEntity;
import com.abdulaziz.HeadHunterFinalProject.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<UserEntity> findAll(){
        return userRepository.findAll();
    }

    public Optional<UserEntity> getById(Long id){
        return Optional.ofNullable(userRepository.findById(id).orElse(null));
    }

    @Transactional
    public void save(UserEntity userEntity){
        userRepository.save(userEntity);
    }

    @Transactional
    public void update(long id, UserEntity userEntity){
        userEntity.setId(id);
        userRepository.save(userEntity);
    }

    @Transactional
    public void delete(long id){
        userRepository.deleteById(id);
    }

}
