package com.abdulaziz.HeadHunterFinalProject.controller;


import com.abdulaziz.HeadHunterFinalProject.dto.ResumeDTO;
import com.abdulaziz.HeadHunterFinalProject.message.ResponseMessage;
import com.abdulaziz.HeadHunterFinalProject.model.FileEntity;
import com.abdulaziz.HeadHunterFinalProject.model.ResumeEntity;
import com.abdulaziz.HeadHunterFinalProject.service.FileService;
import com.abdulaziz.HeadHunterFinalProject.service.FileStorageService;
import com.abdulaziz.HeadHunterFinalProject.service.ResumeService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/resume")
public class ResumeController {

    private final ResumeService resumeService;
    private final ModelMapper mapper;

    private final FileStorageService storageService;


    @Autowired
    public ResumeController(ResumeService resumeService, ModelMapper mapper,FileStorageService storageService) {
        this.resumeService = resumeService;
        this.mapper = mapper;
        this.storageService = storageService;
    }

    @GetMapping
    public List<ResumeDTO> getResumes(){
        return resumeService.findAll().stream()
                .map(this::convertToResumeDTO).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public Optional<ResumeDTO> getResumeById(@PathVariable("id") long id){
        return Optional.ofNullable(convertToResumeDTO(resumeService.getById(id).get()));
    }

    @PostMapping
    public ResponseEntity<HttpStatus> create(@RequestBody ResumeDTO resumeDTO){
        resumeService.save(convertToResume(resumeDTO));
        return ResponseEntity.ok(HttpStatus.CREATED);
    }

    @PostMapping(value = "/files",
            consumes = {MediaType.MULTIPART_FORM_DATA_VALUE},
            produces = {MediaType.APPLICATION_JSON_VALUE} )
    public ResponseEntity<ResponseMessage> uploadFiles(ResumeDTO resumeDTO) {

        String message = "";
        try {
            storageService.save(resumeDTO);
            message = "Uploaded the file successfully";
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
        } catch (Exception e) {
            message = "Could not upload the file: Error: " + e.getMessage();
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
        }
    }





    @PatchMapping("/{id}")
    public ResponseEntity<HttpStatus> update(@RequestBody ResumeDTO resumeDTO, @PathVariable long id){
        resumeService.update(id,convertToResume(resumeDTO));
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> delete(@PathVariable(name = "id") long id){
        resumeService.delete(id);
        return ResponseEntity.ok(HttpStatus.OK);
    }


    public ResumeEntity convertToResume(ResumeDTO resumeDTO){
        return mapper.map(resumeDTO, ResumeEntity.class);
    }
    public ResumeDTO convertToResumeDTO(ResumeEntity resumeEntity){
        return mapper.map(resumeEntity, ResumeDTO.class);
    }


}
