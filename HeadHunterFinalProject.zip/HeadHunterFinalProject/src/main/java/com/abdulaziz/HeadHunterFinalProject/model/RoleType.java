package com.abdulaziz.HeadHunterFinalProject.model;


public enum RoleType {
    ADMIN, COMPANY, EMPLOYEE
}
