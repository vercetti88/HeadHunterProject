package com.abdulaziz.HeadHunterFinalProject.dto;

import jakarta.persistence.*;
import lombok.Data;
import java.util.Date;

@Data
public class UserDTO {
    private String username;
    private String password;
}