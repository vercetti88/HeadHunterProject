package com.abdulaziz.HeadHunterFinalProject.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "role")
public class RoleEntity  {

    @Id
    @Enumerated(EnumType.STRING)
    @JsonIgnore
    @Column(name = "id")
    private RoleType role;

    public RoleEntity(RoleType role) {
        this.role = role;
    }

    @OneToOne(mappedBy = "roleEntity")
    private UserEntity userEntity;

//    @Override
//    public String getAuthority() {
//        return role.name();
//    }
}
