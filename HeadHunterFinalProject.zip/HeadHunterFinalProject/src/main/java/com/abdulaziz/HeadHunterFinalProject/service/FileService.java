package com.abdulaziz.HeadHunterFinalProject.service;

import com.abdulaziz.HeadHunterFinalProject.model.FileEntity;
import com.abdulaziz.HeadHunterFinalProject.repository.FileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class FileService {
    private final FileRepository fileRepository;

    @Autowired
    public FileService(FileRepository fileRepository) {
        this.fileRepository = fileRepository;
    }

    public List<FileEntity> getAllFiles(long id){
        return fileRepository.findAllById(Collections.singleton(id));
    }

    public void save(FileEntity file){
        fileRepository.save(file);
    }


}
