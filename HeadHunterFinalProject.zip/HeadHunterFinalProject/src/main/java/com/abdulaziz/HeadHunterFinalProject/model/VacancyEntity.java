package com.abdulaziz.HeadHunterFinalProject.model;


import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "vacancy")
@Data
@NoArgsConstructor
public class VacancyEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;

    @OneToOne
    @JoinColumn(name = "user_id")
    private UserEntity user;

    @Column(name = "job_title")
    private String  jobTitle;
    @Column(name = "about_company")
    private String aboutCompany;
    @Column(name = "location")
    private String location;
    @Column(name = "requirements")
    private String requirements;
    @Column(name = "salary")
    private int salary;
    @Column(name = "work_type")
    private String workType;
    @Column(name = "experience")
    private String experience;
    @Column(name = "about_vacancy")
    private String aboutVacancy;
    @Column(name = "create_date")
    private Date createDate;
    @Column(name = "status")
    private String status;
}
