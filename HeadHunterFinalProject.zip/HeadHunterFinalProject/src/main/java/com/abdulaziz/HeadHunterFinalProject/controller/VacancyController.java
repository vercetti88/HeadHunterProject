package com.abdulaziz.HeadHunterFinalProject.controller;


import com.abdulaziz.HeadHunterFinalProject.dto.VacancyDTO;
import com.abdulaziz.HeadHunterFinalProject.model.VacancyEntity;
import com.abdulaziz.HeadHunterFinalProject.service.VacancyService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/vacancy")
public class VacancyController {
    private final ModelMapper mapper;

    private final VacancyService vacancyService;

    @Autowired
    public VacancyController(ModelMapper mapper, VacancyService vacancyService) {
        this.mapper = mapper;
        this.vacancyService = vacancyService;
    }

    @GetMapping
    public List<VacancyDTO> getVacancies(){
        return vacancyService.findAll().stream().map(this::convertToVacancyDTO).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public Optional<VacancyDTO> getVacancyById(@PathVariable("id") long id){
        return Optional.ofNullable(convertToVacancyDTO(vacancyService.getById(id).get()));
    }

    @PostMapping
    public ResponseEntity<HttpStatus> create(@RequestBody VacancyDTO vacancyDTO){
        vacancyService.save(convertToVacancy(vacancyDTO));
        return ResponseEntity.ok(HttpStatus.CREATED);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<HttpStatus> update(@RequestBody VacancyDTO vacancyDTO, @PathVariable long id){
        vacancyService.update(id,convertToVacancy(vacancyDTO));
        return ResponseEntity.ok(HttpStatus.OK);
    }
    public VacancyEntity convertToVacancy(VacancyDTO vacancyDTO){
        return mapper.map(vacancyDTO, VacancyEntity.class);
    }
    public VacancyDTO convertToVacancyDTO(VacancyEntity vacancyEntity){
        return mapper.map(vacancyEntity, VacancyDTO.class);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> delete(@PathVariable("id") long id){
        vacancyService.delete(id);
        return ResponseEntity.ok(HttpStatus.OK);
    }




}
