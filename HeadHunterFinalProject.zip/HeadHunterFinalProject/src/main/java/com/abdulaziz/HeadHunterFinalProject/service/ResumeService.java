package com.abdulaziz.HeadHunterFinalProject.service;

import com.abdulaziz.HeadHunterFinalProject.model.ResumeEntity;
import com.abdulaziz.HeadHunterFinalProject.repository.ResumeRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ResumeService {
    private final ResumeRepository resumeRepository;

    @Autowired
    public ResumeService(ResumeRepository resumeRepository) {
        this.resumeRepository = resumeRepository;
    }

    public List<ResumeEntity> findAll(){
        return resumeRepository.findAll();
    }

    public Optional<ResumeEntity> getById(Long id){
        return Optional.ofNullable(resumeRepository.findById(id).orElse(null));
    }

    @Transactional
    public void save(ResumeEntity resumeEntity){
        resumeRepository.save(resumeEntity);
    }

    @Transactional
    public void update(long id, ResumeEntity resumeEntity){
        resumeEntity.setId(id);
        resumeRepository.save(resumeEntity);
    }

    @Transactional
    public void delete(long id){
        resumeRepository.deleteById(id);
    }

}
