package com.abdulaziz.HeadHunterFinalProject.model;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
public class UserEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;

    @Column(name = "username")
    private String username;
    @Column(name = "password")
    private String password;
    @Column(name = "create_date")
    private Date createDate;

    @OneToOne
    @JoinColumn(name = "role_id", referencedColumnName = "id")
    private RoleEntity roleEntity;


    @OneToOne(cascade = CascadeType.DETACH,mappedBy = "user")
    private VacancyEntity vacancyEntity;

    @OneToOne(cascade = CascadeType.REMOVE,mappedBy = "user")
    private ResumeEntity resumeEntity;
}
