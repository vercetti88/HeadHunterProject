package com.abdulaziz.HeadHunterFinalProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeadHunterFinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
